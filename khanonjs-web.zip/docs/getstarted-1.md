# Get Started 1


# What is Khanon.js?

&nbsp;

Link [documentation](https://babylonjs.com/)

Highlight `npm i khanonjs`

Gif ![Alexis Rein](images/alexis.gif)

```
code block
```

&nbsp;
    -  Add different scene maps for each kind of video game (E.g. 3DFPSMap, 2DIsometricMap, 2DVerticalScrollMap, etc)

&nbsp;
    -  Hola