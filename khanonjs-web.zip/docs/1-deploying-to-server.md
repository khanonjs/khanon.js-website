# Deploying your project

To deploy your project, you just need to run the build script `npm run build` and copy all the files from the dist folder to your server.

The `build` script builds the project in debug mode.

If you want to deploy a production version, use `npm run build:prod`. Production version removes all the debug traces from the code, and also removes the Babylon debugging tool dependencies.