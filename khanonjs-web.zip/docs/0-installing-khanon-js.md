# Installing Khanon.js
Khanon.js is installed through the npm repository. Add it to your project as a npm package:

`npm i @khanonjs/engine`

Find the npm page [here](https://www.npmjs.com/package/@khanonjs/engine).