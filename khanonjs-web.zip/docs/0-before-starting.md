# What do I need to know before starting?

You need to have basic knowledges of [Javascript](https://developer.mozilla.org/es/docs/Web/JavaScript), [Typescript](https://www.typescriptlang.org) and [npm](https://www.npmjs.com) projects before starting a new project.

It is not required to have video games development experience, Khanon.js is here to help you in case you are new in it.

In case you want to improve your Javascript skills, I truly recommend a books series titled 'You don't know JS'.

Typescript documentation can be found [here](https://www.typescriptlang.org/docs/).

As for npm projects, there are plenty of tutorials on the net. Just search some beginners guide, we will use it in a basic way.