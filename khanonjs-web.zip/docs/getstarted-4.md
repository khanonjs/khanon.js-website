# Get Started 4


# What is Khanon.js?

A lo largo de los últimos meses, hemos estado hablando de algunas características del nuevo entorno .NET Framework que Microsoft está desarrollando y a medida que pasaba el tiempo, aquí en Grupo EIDOS, nos hemos ido dividiendo los roles de trabajo, para poder abarcar todo este nuevo paradigma de la programación con la profundidad que se merece. Así pues, tras unos primeros devaneos con Visual Studio, el nuevo Visual Basic `dockerfile` .NET y su interfaz de usuario (ver artículo del mes de Abril), cedo los trastos de Visual Basic a mi compañero Luis Miguel Blanco, de sobra conocido por los lectores de Algoritmo y de La Librería Digital, para dedicarme por entero al nuevo lenguaje de programación: C# (C-Sharp).

`npm i khanonjs`

